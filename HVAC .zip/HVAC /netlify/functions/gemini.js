// netlify/functions/gemini.js
const fetch = require('node-fetch');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const { query } = JSON.parse(event.body);

  const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

  const systemPrompt = `Eres un técnico senior de ClimaMaster, empresa mexicana experta en aire acondicionado y refrigeración.

Analiza este problema del cliente: "${query}"

Responde SOLO en español y en formato Markdown limpio con esta estructura exacta:

**Posible causa más probable**
[Explicación clara y tranquilizadora]

**Otras posibles causas**
- Causa 1
- Causa 2
- Causa 3

**Qué puedes hacer ahora de forma segura**
- Acción 1
- Acción 2
- Acción 3

**Recomendación final**
Agenda una visita técnica para solución definitiva. Llama al (961) 816-8217 o déjanos tus datos.

Nunca sugieras abrir el equipo ni manipular partes eléctricas o de gas.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: query }] }],
          systemInstruction: { parts: [{ text: systemPrompt }] },
          generationConfig: { temperature: 0.4, maxOutputTokens: 600 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) throw new Error(data.error?.message || 'Error Gemini');

    const text = data.candidates[0].content.parts[0].text;

    return {
      statusCode: 200,
      body: JSON.stringify({ response: text })
    };

  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Error temporal del asistente IA' })
    };
  }
};